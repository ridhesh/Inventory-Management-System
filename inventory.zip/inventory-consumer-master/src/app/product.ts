export class Product {

    id: number = 0;
    name: string | any;
    brand: string | any;
    madein: string | any;
    price:number | any;
    active: boolean | any;
}