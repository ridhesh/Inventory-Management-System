export class DealerAddress {

    id: number=0;
    email: string='';
    fname: string | any;
    lname: string | any;
    password: string | any;
    dob: Date | any;
    phoneNo:string | any;
 
   // addressId: number;
    street: string | any;
    city: string | any;
    pincode:number | any;
 
    active: boolean=false;
}
